package https://dpc.cms.gov/fhir/v1/ImplementationGuide/cms-dpc-ig;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class DPCPatient {

}
